﻿#pragma once
#include "afxdialogex.h"


#define WM_Edit (WM_USER + 0x0001) //PostMessageのメッセージ番号

using namespace Gdiplus;



// CeditImgDlg ダイアログ

class CeditImgDlg : public CDialog
{
	DECLARE_DYNAMIC(CeditImgDlg)

public:
	CeditImgDlg(CWnd* pParent = nullptr);   // 標準コンストラクター
	virtual ~CeditImgDlg();

	HWND		hWnd;	//親ウィンドウの

	CDC* pDC;
	HDC			hDC;

	CImage		imgBack;
	HDC			hdcBack;
	CDC* pdcBack;

	CImage		imgWork;
	HDC			hdcWork;
	CDC* pdcWork;

	int			Width, Height;
	int			Wx0, Wy0;
	int			mxD, myD, mxM, myM, mxU, myU;
	int			bmxM, bmyM;

	int			btN;
	int			texN;
	int			btY0;
	UINT		nFormat;
	CString		text[10];
	RECT		texRect[10];
	CString		btname[10];
	RECT		btRect[10];
	int			btNoD;
	int			btNoU;
	int			hovNo;

	CBrush		brHaikei;
	COLORREF	Haikei;
	int			wPN;
	int			catchPNo;

	int			fg_catchP;
	int			fg_henkou;
	int			fg_ON[10];
	int			fg_R = 1;
	int			fg_G = 1;
	int			fg_B = 1;
	int			fg_post = 0;

	//GDI+ 
	GdiplusStartupInput gsi;
	ULONG_PTR		token;
	PointF			gPt[256];
	PointF			gPtW[256];
	PointF			gPtR[258];
	PointF			gPtG[258];
	PointF			gPtB[258];


	int				ofX, ofY;
	float			gamY[256];
	float			tens;


	void		getWsize();
	void		setWPos(int, int);
	void		redraw();
	void		textOut(CDC*, RECT, int, CString, COLORREF);
	void		clearBack(CDC*, int, int, int, int, COLORREF);
	void		drawSpline();
	void		drawHG();
	void		reset();
	void		setBT();
	void		drawAllBT(int);
	void		drawBT(int, int);
	void		post();



// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CeditImgDlg };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV サポート

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	CSliderCtrl m_Slc1;
	CSliderCtrl m_Slc2;
	CSliderCtrl m_Slc3;
	CSliderCtrl m_Slc4;
	afx_msg void OnBnClickedCancel();
};

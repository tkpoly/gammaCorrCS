﻿
// gammaCorrCSDlg.h : ヘッダー ファイル
//

#pragma once
#include "buttonDlg.h"
#include "editImgDlg.h"
#include "Cdx11.h"



// CgammaCorrCSDlg ダイアログ
class CgammaCorrCSDlg : public CDialogEx
{
// コンストラクション
public:
	CgammaCorrCSDlg(CWnd* pParent = nullptr);	// 標準コンストラクター

	CbuttonDlg* bt0;
	CeditImgDlg* ediDlg;
	Cdx11	dx11;

	CDC* pDC;
	HWND	hWnd;
	int		imgW, imgH;	//イメージの幅、高さ

	CImage	ImgTex;	//テクスチャ画像編集用
	CDC* pdcTex;
	HDC		hdcTex;
	CBrush	brBlack;

	int		Width, Height;	//クライアントウィンドウの幅、高さ
	int		mxD, myD, mxM, myM, mxU, myU;	//マウスの座標
	int		bfmxM, bfmyM;

	int		fg_Window = 0;
	int		fg_scroll = 0;
	int		fg_1shot = 0;
	int		fg_DX11 = 0;
	int		fg_1shot1 = 0;

	int		m_nFilterLoad = 1;
	int		fg_texON = 0;

	CString	WText = L"";
	CString	FName = _T("");	//ロード画像ファイル名
	CString	FPath = _T("");	//ロード画像ファイルのパス

	CString	sFName = _T("");	//セーブ画像ファイル名
	CString	sFPath = _T("");	//セーブ画像ファイルのパス

	CString strW = _T("");
	CString strH = _T("");


	float	zStep = 0.0f;
	int		zCT = 0;
	float	histmag = 1.0f;
	float	zV = 0.0f;			// ズーム速度
	int		hwZD;				//マウスホイールの移動量（一定値）
	int		tmCT = 0;


	void	getWsize();
	HRESULT	loadImage();
	void	saveImage();
	void	showEdiDlg();
	void	gamma();



// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_GAMMACORRCS_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV サポート


// 実装
protected:
	HICON m_hIcon;

	// 生成された、メッセージ割り当て関数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedOk();
	afx_msg void OnMoving(UINT fwSide, LPRECT pRect);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);

	afx_msg LRESULT  OnBT(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT  OnEdit(WPARAM wParam, LPARAM lParam);

};
